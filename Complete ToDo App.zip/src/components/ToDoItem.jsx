function ToDoItem({ item, handleDeleteClick, index }) {
  return (
    <>
      <div className="row mt-3">
        <div className="col-5">
          {item.name}
        </div>
        <div className="col-5">
          {item.dueDate}
        </div>
        <div className="col-2">
          <button type="button"
            className="btn btn-danger"
            onClick={() => { handleDeleteClick(index) }}
          >Delete</button>
        </div>
      </div>
    </>
  )
}

export default ToDoItem;