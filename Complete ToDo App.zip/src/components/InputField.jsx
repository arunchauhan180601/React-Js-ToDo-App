function InputField({ inputName, inputDate, handleOnChangeName, handleOnChangeDate, handleOnClick }) {
  return (
    <>
      <form onSubmit={handleOnClick}>
        <div className="row">
          <div className="col-5">
            <input type="text"
              placeholder="Enter ToDo Here"
              value={inputName}
              onChange={handleOnChangeName}

            />
          </div>
          <div className="col-5">
            <input type="date"
              value={inputDate}
              onChange={handleOnChangeDate}
            />
          </div>
          <div className="col-2">
            <button
              className="btn btn-success"
            // onClick={handleOnClick}
            >Add</button>
          </div>
        </div>
      </form>
    </>
  )
}

export default InputField;