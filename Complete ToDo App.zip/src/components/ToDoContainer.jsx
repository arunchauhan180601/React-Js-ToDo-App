import ToDoItem from "./ToDoItem";

function ToDoContainer({ todoitems, handleDeleteClick }) {
  return (
    <>
      <div className="todocontainer">
        {todoitems.map((item, index) => {
          return <ToDoItem item={item} key={index} handleDeleteClick={handleDeleteClick} index={index} />

        })}

      </div>
    </>
  )
}

export default ToDoContainer;