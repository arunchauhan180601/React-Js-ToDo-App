export default function ErrorMessage({ ToDoItem }) {
  return (
    <>
      {ToDoItem.length === 0 ? <h4 className="text-center mt-4">Enjoy Your Day</h4> : null}
    </>
  )
}

