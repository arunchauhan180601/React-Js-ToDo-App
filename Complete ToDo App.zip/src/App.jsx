import "bootstrap/dist/css/bootstrap.min.css";
import './App.css';
import Heading from "./components/Heading";
import InputField from "./components/InputField";
import ToDoContainer from "./components/ToDoContainer";
import { useState, useEffect } from "react";
import ErrorMessage from "./components/ErrorMessage";

function App() {
  const [inputName, setInputName] = useState("");
  const [inputDate, setInputDate] = useState("");
  const [ToDoItem, setToDoItem] = useState(() => {
    // Initialize state with data from localStorage if available
    const storedToDoItems = localStorage.getItem("ToDoItem");
    return storedToDoItems ? JSON.parse(storedToDoItems) : [];
  });





  useEffect(() => {
    localStorage.setItem("ToDoItem", JSON.stringify(ToDoItem));
  }, [ToDoItem]);







  function handleOnChangeName(event) {
    setInputName(event.target.value);
  }

  function handleOnChangeDate(event) {
    setInputDate(event.target.value);
  }

  function handleOnClick(event) {
    event.preventDefault();
    if (inputName && inputDate) {
      setToDoItem([...ToDoItem, { name: inputName, dueDate: inputDate }]);
      setInputName("");
      setInputDate("");
    }
  }

  function handleDeleteClick(index) {
    let updatedItems = [...ToDoItem];
    updatedItems.splice(index, 1);
    setToDoItem(updatedItems);
  }

  return (
    <>
      <div className="container">
        <Heading />
        <InputField
          inputName={inputName}
          inputDate={inputDate}
          handleOnChangeName={handleOnChangeName}
          handleOnChangeDate={handleOnChangeDate}
          handleOnClick={handleOnClick}
        />
        <ErrorMessage ToDoItem={ToDoItem} />
        <ToDoContainer todoitems={ToDoItem} handleDeleteClick={handleDeleteClick} />
      </div>
    </>
  );
}

export default App;
